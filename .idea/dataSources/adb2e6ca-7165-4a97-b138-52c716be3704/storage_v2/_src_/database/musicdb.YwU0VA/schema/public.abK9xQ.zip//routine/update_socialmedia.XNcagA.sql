create function update_socialmedia(author_name character varying, instagrams text, twitters text, any_others text) returns void
    language plpgsql
as
$$
DECLARE
    author_ids INTEGER;
BEGIN

    SELECT musicdb.public.list_author.id INTO author_ids
    FROM musicdb.public.list_author
    WHERE musicdb.public.list_author.name = author_name;


    UPDATE musicdb.public.socialmedia
    SET
        instagram = instagrams,
        twitter = twitters,
        any_other = any_others
    WHERE author_id = author_ids;
END;
$$;

alter function update_socialmedia(varchar, text, text, text) owner to postgres;

