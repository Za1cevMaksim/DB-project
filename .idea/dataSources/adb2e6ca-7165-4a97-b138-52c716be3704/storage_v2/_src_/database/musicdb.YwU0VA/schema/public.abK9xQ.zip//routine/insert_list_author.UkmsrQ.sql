create function insert_list_author(names character varying) returns void
    language plpgsql
as
$$
    BEGIN
        INSERT INTO musicdb.public.list_author (name) VALUES (names);
    END;
    $$;

alter function insert_list_author(varchar) owner to users;

