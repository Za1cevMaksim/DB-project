create function select_favorite_songs()
    returns TABLE(song_name character varying, user_id integer)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT musicdb.public.favorite_songs.song_name, musicdb.public.favorite_songs.user_id FROM musicdb.public.favorite_songs;
    END
	$$;

alter function select_favorite_songs() owner to postgres;

