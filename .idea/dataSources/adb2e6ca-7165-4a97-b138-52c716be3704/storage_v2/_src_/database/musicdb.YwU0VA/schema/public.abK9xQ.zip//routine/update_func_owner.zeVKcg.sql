create function update_func_owner() returns void
    language plpgsql
as
$$
    BEGIN
        ALTER FUNCTION musicdb.public.update_value_songs(songs_names varchar) OWNER TO users;
        GRANT EXECUTE ON FUNCTION musicdb.public.update_value_songs(songs_names varchar) TO users;

    END
$$;

alter function update_func_owner() owner to users;

