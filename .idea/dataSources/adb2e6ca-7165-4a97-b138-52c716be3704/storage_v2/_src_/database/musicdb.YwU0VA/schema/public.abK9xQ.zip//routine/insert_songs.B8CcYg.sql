create function insert_songs(song_names character varying, links text, txt_songss text, statuss integer, from_albums character varying) returns void
    language plpgsql
as
$$
    BEGIN
        INSERT INTO musicdb.public.songs (songs_name,link,txt_songs,status,from_album) VALUES (song_names,links,txt_songss,statuss,from_albums);
    END;
    $$;

alter function insert_songs(varchar, text, text, integer, varchar) owner to users;

