create function insert_socialmedia(ids integer, instagrams text, twitters text, any_others text) returns void
    language plpgsql
as
$$
    BEGIN
        INSERT INTO musicdb.public.socialmedia (author_id,instagram,twitter,any_other) VALUES (ids,instagrams,twitters,any_others);
    END;
    $$;

alter function insert_socialmedia(integer, text, text, text) owner to users;

