create function insert_user(user_name character varying, pass_word character varying) returns void
    language plpgsql
as
$$
    BEGIN
        INSERT INTO musicdb.public.users (username, password) VALUES (user_name, pass_word);
    END;
    $$;

alter function insert_user(varchar, varchar) owner to postgres;

