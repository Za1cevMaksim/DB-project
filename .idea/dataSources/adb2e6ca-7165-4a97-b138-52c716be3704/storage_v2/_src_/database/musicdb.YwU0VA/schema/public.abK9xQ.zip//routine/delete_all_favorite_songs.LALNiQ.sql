create function delete_all_favorite_songs() returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM musicdb.public.favorite_songs;
END
$$;

alter function delete_all_favorite_songs() owner to users;

