create function insert_albums(albums_names character varying, years text, author_ids integer) returns void
    language plpgsql
as
$$
    BEGIN
        INSERT INTO musicdb.public.albums (albums_name,year,author_id) VALUES (albums_names,years,author_ids);
    END;
    $$;

alter function insert_albums(varchar, text, integer) owner to users;

