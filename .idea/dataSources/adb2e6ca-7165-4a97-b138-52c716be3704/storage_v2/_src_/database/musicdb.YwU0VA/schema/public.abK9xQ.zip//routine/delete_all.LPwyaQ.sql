create function delete_all() returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM musicdb.public.favorite_songs;
    DELETE FROM musicdb.public.list_author;
    DELETE FROM musicdb.public.socialmedia;
    DELETE FROM musicdb.public.songs;
    DELETE FROM musicdb.public.users;
END
$$;

alter function delete_all() owner to postgres;

