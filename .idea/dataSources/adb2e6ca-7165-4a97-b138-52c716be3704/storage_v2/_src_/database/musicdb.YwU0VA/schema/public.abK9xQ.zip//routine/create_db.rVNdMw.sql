create function create_db(dbname text) returns void
    language plpgsql
as
$$
    BEGIN
        IF EXISTS (SELECT datname FROM pg_database WHERE datname = dbname) THEN
             RAISE NOTICE 'Database already exists';
        ELSE
             PERFORM dblink_exec('user=postgres password=1234 dbname= ' || current_database(),
                    'CREATE DATABASE ' || dbname);
        END IF;
    END;
    $$;

alter function create_db(text) owner to postgres;

