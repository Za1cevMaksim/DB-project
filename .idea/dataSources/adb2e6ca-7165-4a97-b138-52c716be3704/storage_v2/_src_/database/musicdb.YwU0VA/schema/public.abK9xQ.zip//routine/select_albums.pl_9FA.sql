create function select_albums()
    returns TABLE(albums_name character varying, year text, author_id integer)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT musicdb.public.albums.albums_name, musicdb.public.albums.year,musicdb.public.albums.author_id FROM musicdb.public.albums;
    END
	$$;

alter function select_albums() owner to users;

