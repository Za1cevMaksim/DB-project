create function create_tables() returns void
    language plpgsql
as
$$
    BEGIN
        CREATE TABLE IF NOT EXISTS users(
                                    id SERIAL PRIMARY KEY,
                                    username varchar(20) NOT NULL UNIQUE,
                                    password varchar(30) NOT NULL
                                );

        CREATE TABLE IF NOT EXISTS list_author(
                                    id SERIAL PRIMARY KEY,
                                    name varchar(30) NOT NULL UNIQUE
                                );

        CREATE TABLE IF NOT EXISTS albums(
                                    albums_name varchar(30) PRIMARY KEY,
                                    year text NOT NULL UNIQUE,
                                    author_id integer NOT NULL,
                                    FOREIGN KEY (author_id) REFERENCES list_author (id) ON DELETE CASCADE
                                );

        CREATE TABLE IF NOT EXISTS socialmedia(
                                    author_id SERIAL PRIMARY KEY ,
                                    FOREIGN KEY (author_id) REFERENCES list_author (id) ON DELETE CASCADE,
                                    instagram text,
                                    twitter text,
                                    any_other text
                                );

        CREATE TABLE IF NOT EXISTS songs(
            id SERIAL PRIMARY KEY,
            songs_name varchar(40) NOT NULL UNIQUE,
            link text,
            txt_songs text,
            status integer default 0,
            from_album varchar(30) NOT NULL,
            FOREIGN KEY (from_album) REFERENCES albums (albums_name) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS favorite_songs(
                                    id SERIAL PRIMARY KEY,
                                    song_name varchar(40) NOT NULL,
                                    user_id integer NOT NULL,
                                    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
                                    FOREIGN KEY (song_name) REFERENCES songs (songs_name) ON DELETE CASCADE
        );
    END
    $$;

alter function create_tables() owner to postgres;

