create function select_list_author()
    returns TABLE(name character varying)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT musicdb.public.list_author.name FROM musicdb.public.list_author;
    END
	$$;

alter function select_list_author() owner to postgres;

