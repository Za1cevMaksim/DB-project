create function find_author_id(names character varying) returns integer
    language plpgsql
as
$$
DECLARE
    author_id INTEGER;
BEGIN
    SELECT musicdb.public.list_author.id INTO author_id from musicdb.public.list_author
    WHERE musicdb.public.list_author.name=names;

    RETURN author_id;
END
$$;

alter function find_author_id(varchar) owner to postgres;

