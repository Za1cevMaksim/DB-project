create function drop_database(dbname text) returns void
    language plpgsql
as
$$
	BEGIN
		IF EXISTS (SELECT datname FROM pg_database WHERE datname = dbname) THEN
			DROP DATABASE dbname;
		ELSE
			RAISE NOTICE 'Database does not exist';
		END IF;
	END
	$$;

alter function drop_database(text) owner to postgres;

