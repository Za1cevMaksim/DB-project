create function drop_database(dbname text) returns void
    language sql
as
$$
    --ALTER DATABASE musicdb CONNECTION LIMIT 0;
    SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'musicdb';
    SELECT dblink_exec('user=postgres password=1234 dbname = postgres'  , 'DROP DATABASE ' || quote_ident(dbname))
    $$;

alter function drop_database(text) owner to users;

