create function add_default_socialmedia() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO musicdb.public.socialmedia(author_id, instagram,twitter,any_other) VALUES (NEW.id, 'NONE', 'NONE','NONE');
    RETURN NULL;
END
$$;

alter function add_default_socialmedia() owner to postgres;

