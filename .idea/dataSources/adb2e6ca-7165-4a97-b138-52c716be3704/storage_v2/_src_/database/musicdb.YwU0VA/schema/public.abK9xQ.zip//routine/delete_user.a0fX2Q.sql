create function delete_user(usernames character varying) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM musicdb.public.users
    WHERE musicdb.public.users.username = usernames;
END;
$$;

alter function delete_user(varchar) owner to postgres;

