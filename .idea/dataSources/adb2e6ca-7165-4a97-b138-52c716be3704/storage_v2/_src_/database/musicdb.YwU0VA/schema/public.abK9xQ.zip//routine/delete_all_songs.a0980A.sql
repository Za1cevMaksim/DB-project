create function delete_all_songs() returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM musicdb.public.songs;
END
$$;

alter function delete_all_songs() owner to postgres;

