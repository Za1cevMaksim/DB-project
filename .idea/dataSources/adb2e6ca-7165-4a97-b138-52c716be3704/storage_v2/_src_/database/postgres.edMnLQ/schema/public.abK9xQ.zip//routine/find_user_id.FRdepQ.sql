create function find_user_id(names character varying) returns integer
    language plpgsql
as
$$
DECLARE
    user_id INTEGER;
BEGIN
    SELECT musicdb.public.users.id INTO user_id from musicdb.public.users
    WHERE musicdb.public.users.username=names;

    RETURN user_id;
END
$$;

alter function find_user_id(varchar) owner to postgres;

