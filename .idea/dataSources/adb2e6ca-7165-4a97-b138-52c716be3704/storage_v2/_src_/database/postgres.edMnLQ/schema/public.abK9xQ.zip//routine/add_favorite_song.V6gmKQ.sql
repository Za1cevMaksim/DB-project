create function add_favorite_song(usernames character varying, song character varying) returns void
    language plpgsql
as
$$
DECLARE
    user_ids INTEGER;
    song_ids INTEGER;
BEGIN
    SELECT musicdb.public.users.id INTO user_ids
    FROM musicdb.public.users
    WHERE musicdb.public.users.username = usernames;

    SELECT  musicdb.public.songs.id INTO song_ids
    FROM musicdb.public.songs
    WHERE musicdb.public.songs.songs_name = song;

     IF EXISTS (SELECT 1 FROM musicdb.public.favorite_songs WHERE musicdb.public.favorite_songs.user_id = user_ids AND musicdb.public.favorite_songs.song_id = song_ids) THEN
        DELETE FROM musicdb.public.favorite_songs
        WHERE musicdb.public.favorite_songs.user_id = user_ids AND musicdb.public.favorite_songs.song_id = song_ids;
    ELSE
        INSERT INTO musicdb.public.favorite_songs (user_id, song_id)
        VALUES (user_ids, song_ids);
    END IF;
END
$$;

alter function add_favorite_song(varchar, varchar) owner to postgres;

