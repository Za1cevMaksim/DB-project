create function insert_favourite_songs(song_names character varying, user_ids integer) returns void
    language plpgsql
as
$$
    BEGIN
        INSERT INTO musicdb.public.favorite_songs (song_name,user_id) VALUES (song_names,user_ids);
    END;
    $$;

alter function insert_favourite_songs(varchar, integer) owner to postgres;

