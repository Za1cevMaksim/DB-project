create function insert_songs(song_names character varying, links text, from_authors integer) returns void
    language plpgsql
as
$$
    BEGIN
        INSERT INTO musicdb.public.songs (songs_name,link,from_author) VALUES (song_names,links,from_authors);
    END;
    $$;

alter function insert_songs(varchar, text, integer) owner to postgres;

