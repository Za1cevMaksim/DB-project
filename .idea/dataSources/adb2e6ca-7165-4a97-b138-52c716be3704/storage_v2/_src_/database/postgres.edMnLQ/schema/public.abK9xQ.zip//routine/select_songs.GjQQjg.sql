create function select_songs()
    returns TABLE(id integer, songs_name character varying, link text, txt_songs text, status integer, from_album character varying)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT * FROM musicdb.public.songs;
    END
	$$;

alter function select_songs() owner to postgres;

