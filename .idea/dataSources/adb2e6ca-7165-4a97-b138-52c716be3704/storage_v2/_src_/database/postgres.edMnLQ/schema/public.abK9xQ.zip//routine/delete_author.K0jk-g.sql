create function delete_author(author_names character varying) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM musicdb.public.list_author
    WHERE musicdb.public.list_author.name = author_names;
END;
$$;

alter function delete_author(varchar) owner to postgres;

