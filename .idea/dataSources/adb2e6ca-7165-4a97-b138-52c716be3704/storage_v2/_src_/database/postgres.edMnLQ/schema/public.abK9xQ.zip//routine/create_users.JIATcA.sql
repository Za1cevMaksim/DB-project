create function create_users() returns void
    language plpgsql
as
$$
    BEGIN
        CREATE USER users WITH PASSWORD '12345';
        GRANT ALL PRIVILEGES ON DATABASE musicdb TO userss;
        GRANT EXECUTE ON FUNCTION update_value_songs TO userss;
    END
    $$;

alter function create_users() owner to postgres;

