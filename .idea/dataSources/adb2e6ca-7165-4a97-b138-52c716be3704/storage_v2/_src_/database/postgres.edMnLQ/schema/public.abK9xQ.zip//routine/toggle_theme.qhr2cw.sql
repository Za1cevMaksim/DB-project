create function toggle_theme(user_names character varying) returns void
    language plpgsql
as
$$
BEGIN
    UPDATE musicdb.public.users
    SET theme = CASE WHEN musicdb.public.users.theme = 'Light' THEN 'Dark' ELSE 'Light' END
    WHERE musicdb.public.users.username = user_names;
END
$$;

alter function toggle_theme(varchar) owner to postgres;

