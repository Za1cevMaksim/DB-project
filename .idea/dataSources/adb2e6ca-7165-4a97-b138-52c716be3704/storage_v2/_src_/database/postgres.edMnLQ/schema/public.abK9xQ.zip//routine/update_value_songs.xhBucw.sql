create function update_value_songs(songs_names character varying) returns void
    language plpgsql
as
$$
BEGIN
    UPDATE  musicdb.public.songs SET status   = 1
    WHERE songs_name = songs_names;
END
$$;

alter function update_value_songs(varchar) owner to postgres;

