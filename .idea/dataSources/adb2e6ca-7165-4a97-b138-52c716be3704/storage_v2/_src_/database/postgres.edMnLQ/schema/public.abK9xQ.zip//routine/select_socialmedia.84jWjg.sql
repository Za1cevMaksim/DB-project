create function select_socialmedia()
    returns TABLE(author_id integer, instagram text, twitter text)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT musicdb.public.socialmedia.author_id, musicdb.public.socialmedia.instagram, musicdb.public.socialmedia.twitter FROM musicdb.public.socialmedia;
    END
	$$;

alter function select_socialmedia() owner to postgres;

