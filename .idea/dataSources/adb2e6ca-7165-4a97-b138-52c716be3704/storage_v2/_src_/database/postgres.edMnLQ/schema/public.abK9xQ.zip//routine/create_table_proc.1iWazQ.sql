create procedure create_table_proc(IN table_name character varying)
    language plpgsql
as
$$
BEGIN
    EXECUTE 'CREATE TABLE ' || quote_ident(table_name) || ' (id serial PRIMARY KEY)';
END;
$$;

alter procedure create_table_proc(varchar) owner to postgres;

