create function select_users()
    returns TABLE(username character varying, password character varying, theme text)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT musicdb.public.users.username, musicdb.public.users.password, musicdb.public.users.theme FROM musicdb.public.users;
    END
	$$;

alter function select_users() owner to postgres;

