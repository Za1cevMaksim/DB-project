create function select_users()
    returns TABLE(username character varying, password character varying)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT musicdb.public.users.username, musicdb.public.users.password FROM musicdb.public.users;
    END
	$$;

alter function select_users() owner to postgres;

